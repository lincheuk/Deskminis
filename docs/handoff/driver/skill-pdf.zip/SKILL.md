---
name: pdf
description: PDF 处理技能（市场端到端验证用）
---

# Pdf 技能

处理 PDF 的技能正文：提取文本、合并拆分。
